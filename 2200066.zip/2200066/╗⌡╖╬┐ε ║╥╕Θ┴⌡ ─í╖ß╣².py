N = int(input()) # 값 받기 #41

list = []


for i in list:
      # N=41
    N_list1 = list(str(N)) # ['1','4']

    N *= 2
    N_list2 = list(str(N)) # ['2','8']

    if i not in list:

    list.append(N_list1) # ['1','4','2','8']
    
    
    
















while len(N_list) > 10:

    N *= 2
    N_list2 = list(str(N))


    N_list2.append(N_list)
    
    print((N_list2))