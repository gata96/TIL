# T = int(input())
date = list(map(int, input()))
# print(date) #[2, 0, 0, 2, 1, 3, 2, 1]


# for t in range(1, T+1):
    



    
