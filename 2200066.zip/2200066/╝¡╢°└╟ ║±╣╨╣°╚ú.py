p, k = list(map(int, input().split()))

print(p-k+1)